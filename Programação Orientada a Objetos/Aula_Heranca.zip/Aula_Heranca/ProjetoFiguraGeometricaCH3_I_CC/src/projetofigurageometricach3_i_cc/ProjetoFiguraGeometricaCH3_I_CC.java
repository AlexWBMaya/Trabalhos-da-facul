/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package projetofigurageometricach3_i_cc;
import Interface.IFiguraGeometrica;
import modelos.Cilindro;
import modelos.Cone;
import modelos.Esfera;
/**
 *
 * @author ejmcc
 */
public class ProjetoFiguraGeometricaCH3_I_CC {
   private static void imprimir(IFiguraGeometrica objeto, String dado){
        String saida = dado + "\n";
        saida += "Tipo da Figura: " + objeto.getTipoDaFigura() + "\n";
        saida += "Area Total: " + objeto.calcularAreaTotal() + "\n";
        saida += "Volume: " + objeto.calcularVolume() + "\n";
        System.out.println(saida);
    }
  public static void main(String[] args) {
          try {
            Esfera bola = new Esfera(5);
            imprimir(bola, "Dados da Bola");
            Cilindro tubo = new Cilindro(7,5);
            imprimir(tubo, "Dados do Tubo");
            Cone pino = new Cone(5,8);
            
            IFiguraGeometrica obj_a = new Esfera(7);
            IFiguraGeometrica obj_b = new Cilindro(3,4);
            IFiguraGeometrica obj_c = new Cone(4,5);
            imprimir(bola, "Dados da Bola");
            imprimir(tubo, "Dados do Tubo");
            imprimir(pino, "Dados do Pino");
            
            
                    
            
        } catch (Exception erro) {
            System.out.println(erro.getMessage());
        }
  }
}
