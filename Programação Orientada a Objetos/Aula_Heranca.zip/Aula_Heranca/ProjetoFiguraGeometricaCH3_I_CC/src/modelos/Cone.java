/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelos;

import Interface.IFiguraGeometrica;

/**
 *
 * @author ejmcc
 */
public class Cone extends Cilindro{
  public Cone(){
    }
  public Cone(float raio, float altura)throws  Exception{
        super(raio,altura);
    }
    @Override
    public String getTipoDaFigura(){
        return "CONE";
    }
    @Override
    public float calcularAreaTotal(){
        return (float)(Math.PI * raio * (calcularGeratriz() + raio));    
    }
    @Override
    public float calcularVolume(){
        return (float)(1.0/3.0 * Math.PI * raio * raio * altura);
    }    
    @Override
    public float calcularAreaLateral(){
        return (float)(Math.PI * raio * calcularGeratriz());
    }
    public float calcularGeratriz(){
        return (float)(Math.sqrt((altura * altura)+(raio * raio)));
    }
}
