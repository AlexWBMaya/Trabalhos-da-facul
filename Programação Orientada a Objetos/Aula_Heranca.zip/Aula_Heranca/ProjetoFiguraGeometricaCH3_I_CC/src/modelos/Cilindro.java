/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelos;

import Interface.IFiguraGeometrica;

/**
 *
 * @author ejmcc
 */
public class Cilindro extends FiguraGeometrica implements IFiguraGeometrica{
    //Atributos
    protected float altura = 0;
    //Metodos

    public Cilindro() {
    }
    public Cilindro(float raio, float altura) throws  Exception{
      super();
      if(raio <= 0) throw new Exception("Raio não pode ser <= 0");
      this.raio = raio;  
      if(altura <= 0) throw new Exception("ALtura não pode ser <= 0");
      this.altura = altura;
    }

    public float getAltura() {
        return altura;
    }

    public void setAltura(float altura) throws  Exception {
        if(altura <= 0) throw new Exception("ALtura não pode ser <= 0");
        this.altura = altura;
    }

    @Override
    public float calcularAreaTotal() {
        return (float)(2.0 * Math.PI * raio * (altura + raio));
    }
    @Override
    public float calcularVolume() {
        return (float)(Math.PI * raio * raio * altura);
    }
    @Override
    public String getTipoDaFigura() {
        return "CILINDRO";

    }
    public float calcularAreaLateral(){
        return (float)(2.0 * Math.PI * raio * altura);
    }
    
}
