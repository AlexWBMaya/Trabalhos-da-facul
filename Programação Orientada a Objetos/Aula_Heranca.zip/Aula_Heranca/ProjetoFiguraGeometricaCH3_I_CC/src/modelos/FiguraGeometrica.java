/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelos;

/**
 *
 * @author ejmcc
 */
public class FiguraGeometrica {
  //Atributos
  protected float raio=0;
  //Metodos

  public FiguraGeometrica() {
}
  public FiguraGeometrica(float raio) throws Exception {
      if(raio <= 0) throw new Exception("Raio não pode ser <= 0");
      this.raio = raio;
  }
  public float getRaio() {
      return raio;
  }

  public void setRaio(float raio) throws Exception {
      if(raio <= 0) throw new Exception("Raio não pode ser <= 0");
      this.raio = raio;
  }
}
