/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelos;

import Interface.IFiguraGeometrica;

/**
 *
 * @author ejmcc
 */
public class Esfera extends FiguraGeometrica implements IFiguraGeometrica {
    //Atributos vem do pai
    //Metodos

    public Esfera() {
      
    }
    public Esfera(float raio)throws Exception{
        super(raio);
    }
    
    @Override
    public float calcularAreaTotal() {
        return (float) (4.0 * Math.PI * raio * raio);    
    }

    @Override
    public float calcularVolume() {
        return (float)((4.0/3.0) * Math.PI * raio * raio * raio);
    }

    @Override
    public String getTipoDaFigura() {
        return "ESFERA";
    }
}
