/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetofigurageometricach2_i;
import interfaces.IFiguraGeometrica;
import modelos.Cilindro;
import modelos.Cone;
import modelos.Esfera;
/**
 *
 * @author ejmcc
 */
public class ProjetoFiguraGeometricaCH2_I {
    private static void imprimir(IFiguraGeometrica objeto, String dado){
        String saida = dado + "\n";
        saida += "Tipo da Figura: " + objeto.getTipoDaFigura() + "\n";
        saida += "Area Total: " + objeto.calcularAreaTotal() + "\n";
        saida += "Volume: " + objeto.calcularVolume() + "\n";
        System.out.println(saida);
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
            Esfera bola = new Esfera(5);
            imprimir(bola, "Dados da Bola");
            Cilindro tubo = new Cilindro(7,5);
            imprimir(tubo, "Dados do Tubo");
            Cone pino = new Cone(5,8);
            
            IFiguraGeometrica obj_a = new Esfera(7);
            IFiguraGeometrica obj_b = new Cilindro(3,4);
            IFiguraGeometrica obj_c = new Cone(4,5);
            imprimir(bola, "Dados da Bola");
            imprimir(tubo, "Dados do Tubo");
            imprimir(pino, "Dados do Pino");
            
            
                    
            
        } catch (Exception erro) {
            System.out.println(erro.getMessage());
        }
    }
    
}
