/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelos;
import interfaces.IFiguraGeometrica;
/**
 *
 * @author ejmcc
 */
public class Cilindro implements IFiguraGeometrica{
    //Atributos
    protected float raio = 0;
    protected float altura = 0;
    //Metodos

    public Cilindro() {
    }
    public Cilindro(float raio, float altura) throws  Exception{
        if(raio <= 0) throw new Exception("Raio não pode ser <= 0");
        if(altura <= 0) throw new Exception("ALtura não pode ser <= 0");
        this.raio = raio;
        this.altura = altura;
    }

    public float getRaio() {
        return raio;
    }

    public void setRaio(float raio)throws  Exception {
        if(raio <= 0) throw new Exception("Raio não pode ser <= 0");
        this.raio = raio;
    }

    public float getAltura() {
        return altura;
    }

    public void setAltura(float altura) throws  Exception {
        if(altura <= 0) throw new Exception("ALtura não pode ser <= 0");
        this.altura = altura;
    }

    @Override
    public float calcularAreaTotal() {
        return (float)(2.0 * Math.PI * raio * (altura + raio));
    }
    @Override
    public float calcularVolume() {
        return (float)(Math.PI * raio * raio * altura);
    }
    @Override
    public String getTipoDaFigura() {
        return "CILINDRO";

    }
    public float calcularAreaLateral(){
        return (float)(2.0 * Math.PI * raio * altura);
    }
    
}
